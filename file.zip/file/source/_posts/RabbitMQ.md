---
title: RabbitMQ
date: 2022-09-23 14:58:06
categories: 技术
tags: RabbitMQ
---



MQ消息队列

## MQ的三个作用

- 流量削峰
- 应用解耦
- 异步处理

<!--more-->

一个Connection里面有多个Channel，可以大幅度降低开销

![image-20220923161711179](https://github.com/littlebean1/littlebean1.github.io/blob/main/myImage/MQgzyl.png?raw=true)



## MQ的安装

https://blog.csdn.net/m0_67392182/article/details/126040124

安装rabbitmq需要安装其依赖的环境erlang，然后在安装rabbitmq

- **systemctl restart rabbitmq-server**					             重启rabbitmq服务

- **systemctl stop rabbitmq-server**						              终止rabbitmq服务

- **systemctl stop firewalld**					 				               取消防火墙

- **systemctl enable firewalld**				 				              将状态持久化

- **rabbitmqctl add_user admin 123**	 				               添加rabbitmq用户

- **rabbitmqctl set_user admin administrator**	             修改rabbitmq用户的权限

- **rabbitmq-plugins enable rabbitmq_management**     安装rabbitmq的web端的客户端插件
