---
title: git学习
date: 2022-09-29 14:41:59
categories: 技术
tags: git
---







### git命令

- git init                              //初始化git

- git status                         //查看本地工作区状态

- git add a.txt                    //将本地工作区的a.txt文件推到缓存区

- git rm --cached  a.txt     //删除缓存区的a.txt文件

  <!--more-->

- git commit -m "first commit" a.txt     //第一次提交a.txt文件到本地库

- git log                              //查看版本信息

- git reset --hard 版本号前七位      //版本穿梭

- git branch -v                   //查看所有分支

- git branch branch1       //创建分支branch1

- git checkout branch1    //切换到分支branch1 ，修改分支branch1不会影响分支master

- git remote -v                   //查看当前仓库门

- git remote add littleberan1 https://github.com/littlebean1/littlebean1.github.io.git  //给远程仓库重命名

- git push littlebean1 master  //向littlebean1仓库推送master分支

- git pull littlebean1 master    //从littlebean1仓库拉取master分支

- git clone  https://github.com/littlebean1/littlebean1.github.io.git   //克隆littlebean1仓库到本地库





![团队内协作](https://github.com/littlebean1/littlebean1.github.io/blob/main/myImage/workInGroup.png?raw=true)



![团队外协作](https://github.com/littlebean1/littlebean1.github.io/blob/main/myImage/workOutGroup.png?raw=true)
